from django.urls import path

# Define URL patterns for the documents app. Keep empty for now to
# avoid import errors while the app's views are implemented.
urlpatterns = []
